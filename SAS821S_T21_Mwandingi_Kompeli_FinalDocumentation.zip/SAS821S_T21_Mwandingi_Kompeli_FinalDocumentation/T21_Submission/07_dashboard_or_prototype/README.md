# T21 Analyst Prototype

Open `t21_analyst_prototype.html` in a modern web browser. The prototype is a static, self-contained analyst-facing dashboard generated from the reproducible outputs in `08_outputs/`.

Implemented workflow: load/refresh -> baseline -> supervised high-risk sessions -> anomaly sessions -> predictive risk -> incident timeline -> intelligence -> simulation -> NLP.

All data are synthetic. The prototype provides decision support and does not execute containment or other operational actions.
