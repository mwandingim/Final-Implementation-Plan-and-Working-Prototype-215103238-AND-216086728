# Processed Data

The current implementation performs transformations in memory and writes analytical outputs to `08_outputs/`. No separate processed-data file is required for the reported results.
