# T21 Maritime Port Security Analytics — Data Generation Methodology

## 1. Purpose
This package provides a controlled, fictional multi-source dataset for the SAS821S T21 project:
**Maritime Port and Cargo-Terminal Cyber-Physical Security Analytics**.

The dataset is designed to support data engineering, behavioural baselining, supervised and unsupervised analytics,
incident timeline reconstruction, security intelligence, simulation, NLP, predictive risk scoring and adversarial testing.

## 2. Alignment with the approved project
The project charter specifies synthetic representations of OT/SCADA telemetry, vendor VPN/IAM access, network flows,
cargo/manifest events, physical access, endpoint alerts and maintenance notes. The capstone specification requires
at least three security sources, at least 5,000 combined records, a labelled dataset, an unlabelled/semi-labelled
dataset, at least 200 text records and documented provenance.

## 3. Synthetic environment
The fictional environment represents a container terminal with:
- 8 cranes
- 12 PLC assets
- 8 yard controllers
- 20 fictional vendors
- 60 fictional accounts
- 100 fictional devices
- 150 fictional badges
- fictional containers, gates and operational zones

No real port, company, customer, employee, vendor credential or production system is represented.

## 4. Primary datasets and volumes
| Dataset | Target/actual records | Main analytical purpose |
|---|---:|---|
| t21_vendor_vpn_iam.csv | 1,800 | Identity/access and vendor behaviour |
| t21_ot_scada_crane.csv | 2,016 | OT/SCADA command and alarm analytics |
| t21_network_flows.csv | 2,200 | Network anomaly and intrusion analytics |
| t21_endpoint_alerts.csv | 1,200 | Endpoint security analytics |
| t21_cargo_manifest.csv | 1,204 | Cargo-integrity context |
| t21_physical_access.csv | 1,004 | Physical access correlation |
| t21_maintenance_notes.csv | 304 | Text mining/NLP |
| t21_asset_inventory.csv | 28 | Asset and operational context |
| t21_integrated_security_events.csv | 9,728 | Derived cross-source event index |

The seven event sources alone contain 9,728 event/transaction records.

## 5. Time and identifiers
All timestamps are stored in UTC ISO-8601 format.
Common correlation identifiers include:
- vendor_id
- account_id
- device_id
- asset_id
- incident_id
- timestamp

Incident windows use shared incident_id values so events from multiple sources can be reconstructed chronologically.

## 6. Scenario injection
Four controlled incident scenarios are injected into otherwise normal synthetic activity:

- S01 — Compromised vendor account
- S02 — Unauthorized OT command sequence
- S03 — Remote administration and unusual data transfer
- S04 — Cargo/manifest manipulation

A separate S00 normal-operation scenario forms the behavioural baseline.

The injected events are intentionally non-operational and do not provide instructions for attacking real systems.

## 7. Label strategy
The primary event labels are:
- NORMAL
- SUSPICIOUS
- INCIDENT

For modelling, NORMAL is mapped to binary 0 and SUSPICIOUS/INCIDENT to binary 1.
Labels are generated from the scenario logic rather than copied from real incidents.

## 8. Data quality controls
The generator uses:
- fixed random seed: 210821
- explicit field types and controlled categorical values
- fictional/test identifiers
- consistent UTC timestamps
- deterministic cross-source incident IDs
- documented generation rules
- no real credentials or customer data

## 9. Intended analytical use
The package supports:
1. descriptive statistics and baseline analysis;
2. supervised classification;
3. anomaly/behavioural detection;
4. cross-source incident investigation;
5. threat-intelligence enrichment;
6. three-control simulation;
7. NLP on maintenance/incident text;
8. predictive risk scoring and robustness/adversarial tests.

## 10. Limitations
This is a synthetic research dataset. It does not represent the actual traffic, control logic, asset configuration,
risk profile or operational procedures of a real port. Results must therefore be interpreted as prototype/educational
evidence rather than production security measurements.

## 11. Reproducibility
Run:

```bash
python code/generate_t21_dataset.py
```

The generator recreates the CSV outputs using the same seed. The package should be version-controlled so that
changes to generation logic and outputs can be audited.
