# T21 Maritime Port Security Analytics — Synthetic Dataset Package

Generated: 2026-09-15
Random seed: 210821
Date range: 2026-06-01 to 2026-06-30 UTC

## Contents
- `data/` — eight primary synthetic datasets plus integrated event index and scenario catalogue.
- `documentation/` — data dictionary, provenance record, generation methodology and scenario specification.
- `code/generate_t21_dataset.py` — reproducible generator.

## Safety and academic-use statement
All identities, IP addresses, devices, assets, containers, badges, alarms and events are fictional.
Documentation/test IP ranges are used. No live port, OT, SCADA, crane, vendor or customer data is included.

## Main record count
Seven event sources: 9,728
Asset inventory: 28
