# T21 Scenario Injection Specification

| Scenario | Core signal chain | Expected analytical evidence |
|---|---|---|
| S00 Normal | Routine VPN -> normal endpoint -> normal OT/network activity | Baseline |
| S01 Compromised vendor account | Off-hours VPN + weak/failed MFA + new device -> endpoint remote tool -> OT command -> cargo change | Account compromise hypothesis |
| S02 Unauthorized OT sequence | Vendor access -> OT mode change -> unauthorized command -> crane/PLC alarm | OT command anomaly |
| S03 Remote admin/data transfer | Remote administration -> unusual outbound traffic -> restricted physical access | Endpoint/network/physical correlation |
| S04 Cargo manipulation | Anomalous access -> manifest destination change -> security/maintenance note | Cargo-integrity anomaly |

All scenario events are fictional and use non-operational identifiers.
