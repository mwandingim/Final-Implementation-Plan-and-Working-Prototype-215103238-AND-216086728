# Final Evidence-to-Code Verification

Date: 22 September 2026

The submitted reproducibility pipeline was executed from the project root using:

`python 03_notebooks_or_scripts/run_analysis_pipeline.py`

Result: **Pipeline completed successfully.**

## Verified implementation results

| Evidence | Verification result |
|---|---|
| Primary security events | 9,728 |
| Maintenance/text records | 304 |
| Assets | 28 |
| Vendor VPN/IAM sessions | 1,800 |
| Supervised Random Forest | 98.52% accuracy; 96.15% precision; 78.13% recall; 86.21% F1; 21.88% FNR |
| Isolation Forest | 90 anomalies; 92.22% post-hoc precision; 78.30% recall; 84.69% F1 |
| Predictive Random Forest | 95.56% accuracy; 53.66% precision; 81.48% recall; 64.71% F1; 18.52% FNR |
| NLP | 100% accuracy/precision/recall/F1; 0% FNR on the synthetic held-out corpus |
| Incident INC-T21-001 | 37 correlated events; 22:38–22:59 UTC, 5 June 2026 |
| Simulation | 10,000 iterations per scenario; baseline mean risk 34.41 |
| Simulation controls | MFA/session 11.19; segmentation 14.36; monitoring 19.25 mean risk index |
| Final QA | T01–T05: 5/5 PASS |

## Prototype filter verification

The prototype session filter searches the embedded supervised and anomaly result tables. The actual vendor identifier format is `V014` (three digits after `V`), not `V0014`. Searching for `V014` returns matching supervised and anomaly records, including the primary-incident account `ACC0014` and device `DEV0099` where present.

## Data provenance

All analytical records used for the reported results are synthetic T21 data. Public datasets discussed during project research were not represented as datasets used in the reported experiments.

## Reproducibility note

The pipeline was executed successfully from the packaged project root without absolute-path dependencies. Outputs and model artefacts were regenerated under `08_outputs/` and `04_models/`.
