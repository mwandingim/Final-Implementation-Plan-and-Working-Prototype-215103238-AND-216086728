# Contribution Evidence Log

This log provides an evidence-based summary of the workstream allocation. It is not a fabricated Git commit history.

| Workstream | Primary contributor | Evidence |
|---|---|---|
| Synthetic data generation and validation | Mwandingi Marshall | `03_notebooks_or_scripts/00_generate_t21_dataset.py`, `01_validate_dataset.py`, validation outputs |
| Baseline and supervised modelling | Mwandingi Marshall | `03_baseline_eda.py`, `05_supervised_model.py`, corresponding outputs and model metadata |
| Anomaly/access analytics | Mwandingi Marshall | `07_anomaly_access_analytics.py`, anomaly outputs and model |
| Incident investigation | Kompeli Ezira | `08_incident_investigation.py`, timeline, hypothesis and response outputs |
| Security intelligence | Kompeli Ezira | `10_security_intelligence.py`, PIRs, indicators, enrichment and intelligence products |
| Simulation | Kompeli Ezira | `12_simulation.py`, scenario and sensitivity outputs |
| NLP/text mining | Kompeli Ezira | `14_text_mining_nlp.py`, NLP outputs and model |
| Predictive/adversarial analytics | Mwandingi Marshall | `16_predictive_adversarial.py`, predictive/adversarial outputs and model |
| Prototype and QA | Both | `18_prototype.py`, `19_final_qa.py`, prototype and QA evidence |
| Documentation | Both | Final implementation plan and supporting documentation |

Both students should review and sign their individual contribution statements before submission.
