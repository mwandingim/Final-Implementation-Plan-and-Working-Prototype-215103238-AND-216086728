# Individual Contribution Statement — Mwandingi Marshall

**Student number:** 215103238  
**Project:** T21 Maritime Port and Cargo-Terminal Cyber-Physical Security Analytics  
**Role:** Data and Modelling Lead

I confirm that I contributed meaningfully to the T21 project and reviewed the submitted implementation and documentation. My primary contribution areas were synthetic data generation and validation, baseline/EDA, supervised and predictive modelling, reproducibility, and technical documentation.

I confirm that I can explain the components attributed to me and the evidence included in the submission.

Signature: ______________________________  
Date: __________________________________
