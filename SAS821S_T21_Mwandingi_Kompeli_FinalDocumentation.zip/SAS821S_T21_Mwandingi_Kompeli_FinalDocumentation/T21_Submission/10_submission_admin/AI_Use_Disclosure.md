# AI and Coding-Assistant Use Disclosure

## T21 Maritime Port and Cargo-Terminal Cyber-Physical Security Analytics

We used AI in our project to assist with the following, Python syntax assistance, troubleshooting, code organisation and quality assurance review.

AI assistance was not treated as independent evidence. The we reviewed, executed and verified the implemented code, generated outputs, metrics, figures and written claims. 
The submitted implementation includes the reproducible Python scripts, generated outputs, model artefacts and documentation needed to inspect and reproduce the reported results.

**Student A:** Mwandingi Marshall  
**Student B:** Kompeli Ezira  

Signatures: __________________________ / __________________________  
Date: ________________________________
