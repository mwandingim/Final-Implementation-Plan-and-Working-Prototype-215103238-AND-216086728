# T21 Presentation Outline

1. **Problem and decision context** — maritime terminal cyber-physical security problem and decision supported.
2. **Synthetic data and governance** — sources, provenance, quality and safety boundaries.
3. **Architecture and workflow** — implemented data flow from sources to analyst decision support.
4. **Baseline and supervised analytics** — behavioural baseline, Random Forest results and interpretation.
5. **Anomaly and incident investigation** — anomaly detection and correlated incident timeline.
6. **Security intelligence and simulation** — PIRs, enrichment and control-scenario comparison.
7. **NLP and predictive/adversarial analysis** — text classifier, predictive risk and stress tests.
8. **Prototype demonstration** — analyst workflow and evidence views.
9. **Limitations and responsible use** — synthetic data, model limitations and human review.
10. **Conclusion** — how the integrated analytics support defensible security decisions.
