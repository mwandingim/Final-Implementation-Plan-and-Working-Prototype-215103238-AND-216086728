# Individual Contribution Statement — Kompeli Ezira

**Student number:** 216086728  
**Project:** T21 Maritime Port and Cargo-Terminal Cyber-Physical Security Analytics  
**Role:** Security Engineering and Intelligence Lead

I confirm that I contributed meaningfully to the T21 project and reviewed the submitted implementation and documentation. My primary contribution areas were incident investigation, security intelligence, NLP/simulation support, prototype/testing and technical documentation.

I confirm that I can explain the components attributed to me and the evidence included in the submission.

Signature: ______________________________  
Date: __________________________________
