# Team Contribution Declaration

**Project:** T21 Maritime Port and Cargo-Terminal Cyber-Physical Security Analytics  
**Course:** SAS821S Security Analytics  
**Institution:** Namibia University of Science and Technology  

We confirm that both registered members contributed meaningfully to the project and reviewed the submitted implementation and documentation.

| Member | Student No. | Primary role | Contribution evidence |
|---|---|---|---|
| Mwandingi Marshall | 215103238 | Data and Modelling Lead | Data generation/validation, baseline and modelling implementation, reproducibility and documentation |
| Kompeli Ezira | 216086728 | Security Engineering and Intelligence Lead | Investigation, security intelligence, NLP/simulation support, prototype/testing and documentation |

Both members remain responsible for the accuracy of the submitted results, code and references.

**Mwandingi Marshall**  
Signature: __________________________  Date: __________________

**Kompeli Ezira**  
Signature: __________________________  Date: __________________
