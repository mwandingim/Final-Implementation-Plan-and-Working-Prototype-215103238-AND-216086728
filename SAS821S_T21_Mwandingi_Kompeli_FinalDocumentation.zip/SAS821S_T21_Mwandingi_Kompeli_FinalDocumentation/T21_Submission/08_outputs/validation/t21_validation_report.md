# T21 Dataset Validation Report

## 1. Purpose
This validation establishes a reproducible quality baseline before exploratory analysis and modelling. It checks row counts, schema size, timestamps, missing values, duplicate rows/event identifiers, labels and project-wide coverage.

## 2. Project-level results
- Validation status: **PASS**
- Primary event/transaction records: **9,728**
- Primary records including asset inventory: **9,756**
- Unstructured maintenance-note records: **304**
- Overall event date range: **2026-06-01T00:10:04+00:00 to 2026-06-30T23:56:58+00:00**
- Integrated event binary-label mapping: **PASS**

## 3. Dataset checks

| dataset                    | file                               |   rows |   columns | date_min_utc              | date_max_utc              |   missing_cells |   columns_with_missing |   duplicate_rows |   duplicate_event_ids |   unique_event_ids |   invalid_timestamps | timestamp_validation   | label_distribution                       |
|:---------------------------|:-----------------------------------|-------:|----------:|:--------------------------|:--------------------------|----------------:|-----------------------:|-----------------:|----------------------:|-------------------:|---------------------:|:-----------------------|:-----------------------------------------|
| asset_inventory            | t21_asset_inventory.csv            |     28 |         9 |                           |                           |               0 |                      0 |                0 |                   nan |                nan |                    0 | N/A                    |                                          |
| cargo_manifest             | t21_cargo_manifest.csv             |   1204 |        11 | 2026-06-01T00:10:04+00:00 | 2026-06-30T23:53:31+00:00 |            1200 |                      1 |                0 |                     0 |               1204 |                    0 | PASS                   | NORMAL=1160; SUSPICIOUS=40; INCIDENT=4   |
| endpoint_alerts            | t21_endpoint_alerts.csv            |   1200 |        11 | 2026-06-01T00:44:32+00:00 | 2026-06-30T23:54:07+00:00 |            1167 |                      1 |                0 |                     0 |               1200 |                    0 | PASS                   | NORMAL=1104; SUSPICIOUS=96               |
| integrated_security_events | t21_integrated_security_events.csv |   9728 |         6 | 2026-06-01T00:10:04+00:00 | 2026-06-30T23:56:58+00:00 |            9591 |                      1 |                0 |                     0 |               9728 |                    0 | PASS                   | NORMAL=9083; SUSPICIOUS=617; INCIDENT=28 |
| maintenance_notes          | t21_maintenance_notes.csv          |    304 |         9 | 2026-06-01T00:39:19+00:00 | 2026-06-30T22:33:57+00:00 |             300 |                      1 |                0 |                   nan |                nan |                    0 | PASS                   | NORMAL=236; SUSPICIOUS=64; INCIDENT=4    |
| network_flows              | t21_network_flows.csv              |   2200 |        15 | 2026-06-01T00:47:32+00:00 | 2026-06-30T23:29:01+00:00 |            2163 |                      1 |                0 |                     0 |               2200 |                    0 | PASS                   | NORMAL=2040; SUSPICIOUS=160              |
| ot_scada_crane             | t21_ot_scada_crane.csv             |   2016 |        11 | 2026-06-01T01:13:26+00:00 | 2026-06-30T23:56:58+00:00 |            1979 |                      1 |                0 |                     0 |               2016 |                    0 | PASS                   | NORMAL=1903; SUSPICIOUS=97; INCIDENT=16  |
| physical_access            | t21_physical_access.csv            |   1004 |        10 | 2026-06-01T00:28:11+00:00 | 2026-06-30T22:54:50+00:00 |            1000 |                      1 |                0 |                     0 |               1004 |                    0 | PASS                   | NORMAL=946; SUSPICIOUS=54; INCIDENT=4    |
| scenario_catalogue         | t21_scenario_catalogue.csv         |      5 |         5 |                           |                           |               0 |                      0 |                0 |                   nan |                nan |                    0 | N/A                    |                                          |
| vendor_vpn_iam             | t21_vendor_vpn_iam.csv             |   1800 |        15 | 2026-06-01T01:31:11+00:00 | 2026-06-30T23:27:04+00:00 |            1782 |                      1 |                0 |                     0 |               1800 |                    0 | PASS                   | NORMAL=1694; SUSPICIOUS=106              |

## 4. Quality interpretation
The dataset is synthetic and deterministic. A clean result here means the files are structurally ready for analysis; it does not mean the synthetic data are free from modelling bias or that the simulated patterns represent real port operations.

## 5. Issues requiring attention
- No structural validation failures were detected in Step 1.

## 6. Reproducibility
Run `python 03_notebooks_or_scripts/01_validate_dataset.py` from the project root. The script writes the CSV quality summaries and this report under `08_outputs/validation/`.