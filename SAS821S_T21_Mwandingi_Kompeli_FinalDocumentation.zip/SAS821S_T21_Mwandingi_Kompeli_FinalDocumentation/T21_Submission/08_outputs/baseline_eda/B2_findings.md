# Baseline and Exploratory Analysis Findings

- Seven primary security sources were analysed, containing 9,728 records.
- Vendor VPN/IAM contains 1,800 sessions; 106 are labelled non-normal (5.89%).
- Individual vendor baseline: V014 has the highest non-normal session rate at 13.19% (12/91).
- Peer-group baseline: NetworkVendor has the highest non-normal rate at 6.99% (27/386).
- Behavioural observation: suspicious sessions occur disproportionately during off-hours; this is treated as a baseline deviation indicator, not proof of compromise.
- New-device activity is concentrated in suspicious sessions in the synthetic dataset, supporting its use as a candidate feature for the supervised/anomaly stages.
