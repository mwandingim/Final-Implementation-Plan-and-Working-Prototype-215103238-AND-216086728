# T21 Maritime Port and Cargo-Terminal Cyber-Physical Security Analytics

**SAS821S Security Analytics — Namibia University of Science and Technology — Semester 2, 2026**

## 1. Project purpose
This submission contains the reproducible implementation for Topic T21. The project uses a controlled synthetic maritime-terminal environment to analyse vendor remote access, OT/SCADA activity, network behaviour, cargo/manifest events, physical access, endpoint alerts and maintenance notes.

## 2. Submission contents
- `01_charter/` — approved T21 project charter.
- `02_data/raw/` — synthetic source datasets used by the implementation.
- `02_data/processed/` — reserved for derived/cleaned datasets where applicable.
- `03_notebooks_or_scripts/` — complete Python implementation and QA scripts.
- `04_models/` — trained model artefacts and metadata.
- `05_simulation/` — simulation documentation.
- `06_text_mining/` — NLP documentation.
- `07_dashboard_or_prototype/` — functional analyst-facing prototype.
- `08_outputs/` — figures, metrics, tables, timelines and QA evidence.
- `09_documentation/` — final implementation plan, PDF export, data documentation and appendices.
- `10_submission_admin/` — AI disclosure, contribution declaration and final submission checklist.
- `requirements.txt` — Python dependencies.

## 3. Synthetic-data statement
All project records are synthetic and fictional. They do not represent a real port, real customer, real vendor, real credentials, or production OT/SCADA systems. No live testing was conducted. Public material is used only as documented reference or contextual intelligence enrichment.

## 4. Reproducibility
From the project root, create a Python environment and install the dependencies in `requirements.txt`. Then run:

```bash
python 03_notebooks_or_scripts/run_analysis_pipeline.py
```

The pipeline executes the dataset generator, validation, baseline/EDA, supervised model, anomaly analytics, incident investigation, intelligence, simulation, NLP, predictive/adversarial analysis, prototype generation and final QA in sequence.

The pipeline uses a deterministic seed of **210821** where applicable. Generated outputs are written to `08_outputs/` and model artefacts to `04_models/`.

## 5. Main evidence
- Dataset validation: `08_outputs/validation/`
- Baseline/EDA: `08_outputs/baseline_eda/`
- Supervised model: `08_outputs/supervised_model/`
- Anomaly analytics: `08_outputs/anomaly_access/`
- Incident investigation: `08_outputs/incident_investigation/`
- Security intelligence: `08_outputs/security_intelligence/`
- Simulation: `08_outputs/simulation/`
- NLP: `08_outputs/text_mining/`
- Predictive/adversarial: `08_outputs/predictive_adversarial/`
- Prototype: `07_dashboard_or_prototype/t21_analyst_prototype.html`
- Final QA: `08_outputs/final_qa/`

## 6. Main documents
- `01_charter/Capstone_Project_Charter_T21.pdf`
- `09_documentation/SAS821S_T21_Mwandingi_Kompeli_Implementation_Plan_Final.docx`
- `09_documentation/SAS821S_T21_Mwandingi_Kompeli_Implementation_Plan_Final.pdf`
- `09_documentation/SAS821S_T21_Mwandingi_Kompeli_Final_Documentation.docx`
- `09_documentation/SAS821S_T21_Mwandingi_Kompeli_Final_Documentation.pdf`
- `10_submission_admin/AI_Use_Disclosure.md`
- `10_submission_admin/Team_Declaration.md`
- `10_submission_admin/Final_Submission_Checklist.md`

## 7. Academic integrity and safety
Only synthetic/controlled data are included. No passwords, API keys, access tokens, malware samples, unauthorised personal data or live production records are included. The group remains responsible for verifying all results and references.
