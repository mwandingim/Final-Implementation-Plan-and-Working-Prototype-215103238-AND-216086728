import os, json, math, random, textwrap, zipfile
from pathlib import Path
from datetime import datetime, timedelta, timezone
import numpy as np
import pandas as pd

# -----------------------------
# T21 Maritime Port Synthetic Dataset Generator
# -----------------------------
SEED = 210821
rng = np.random.default_rng(SEED)
random.seed(SEED)

BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "02_data" / "raw"
DOCS = BASE / "09_documentation" / "data_generation"
CODE = BASE / "03_notebooks_or_scripts"
for p in [DATA, DOCS, CODE]:
    p.mkdir(parents=True, exist_ok=True)

START = datetime(2026, 6, 1, 0, 0, tzinfo=timezone.utc)
END = datetime(2026, 6, 30, 23, 59, tzinfo=timezone.utc)

vendors = [f"V{n:03d}" for n in range(1, 21)]
accounts = [f"ACC{n:04d}" for n in range(1, 61)]
devices = [f"DEV{n:04d}" for n in range(1, 101)]
assets = [f"CRANE{n:02d}" for n in range(1, 9)] + [f"PLC{n:02d}" for n in range(1, 13)] + [f"YARD-{n:02d}" for n in range(1, 9)]
zones = ["GATE-A", "GATE-B", "YARD-A", "YARD-B", "YARD-C", "OT-ZONE", "CRANE-ZONE", "CONTROL-ROOM"]
roles = ["CraneVendor", "MaintenanceVendor", "NetworkVendor", "AutomationVendor", "YardVendor"]
protocols = ["TCP", "UDP", "ICMP"]
ports = [22, 80, 443, 502, 44818, 3389, 8080, 8443, 161, 53]
processes = ["vendor_agent", "maintenance_client", "browser", "ssh", "rdp", "plc_tool", "sensor_service", "yard_client", "remote_admin_tool"]
normal_commands = ["HOIST_UP", "HOIST_DOWN", "MOVE_LEFT", "MOVE_RIGHT", "STOP", "IDLE", "SPEED_SET", "STATUS_READ"]
suspicious_commands = ["UNAUTHORIZED_COMMAND", "PLC_MODE_CHANGE", "OUT_OF_SEQUENCE", "EMERGENCY_STOP", "SPEED_OVERRIDE", "REPEATED_COMMAND"]

# Stable mappings make cross-source joins meaningful.
vendor_account = {a: vendors[(i*3) % len(vendors)] for i, a in enumerate(accounts)}
account_role = {a: roles[i % len(roles)] for i, a in enumerate(accounts)}
account_device = {a: devices[(i*2) % len(devices)] for i, a in enumerate(accounts)}
device_asset = {d: assets[i % len(assets)] for i, d in enumerate(devices)}

def rand_ts():
    seconds = int((END - START).total_seconds())
    return START + timedelta(seconds=int(rng.integers(0, seconds + 1)))

def fmt(dt):
    return dt.isoformat().replace("+00:00", "Z")

def ip_for(idx, malicious=False):
    if malicious:
        return f"198.51.100.{int(rng.integers(10, 240))}"  # TEST-NET-2 documentation range
    return f"192.0.2.{(idx % 220) + 10}"  # TEST-NET-1 documentation range

# Incident windows shared across all relevant datasets.
incidents = [
    {"incident_id":"INC-T21-001","scenario_id":"S01","start":datetime(2026,6,5,22,40,tzinfo=timezone.utc),
     "vendor_id":"V014","account_id":"ACC0014","device_id":"DEV0099","asset_id":"CRANE03","container_id":"CONT-004821"},
    {"incident_id":"INC-T21-002","scenario_id":"S02","start":datetime(2026,6,12,1,15,tzinfo=timezone.utc),
     "vendor_id":"V006","account_id":"ACC0031","device_id":"DEV0062","asset_id":"PLC07","container_id":"CONT-003118"},
    {"incident_id":"INC-T21-003","scenario_id":"S03","start":datetime(2026,6,18,23,5,tzinfo=timezone.utc),
     "vendor_id":"V019","account_id":"ACC0058","device_id":"DEV0087","asset_id":"CRANE06","container_id":"CONT-006904"},
    {"incident_id":"INC-T21-004","scenario_id":"S04","start":datetime(2026,6,24,19,30,tzinfo=timezone.utc),
     "vendor_id":"V011","account_id":"ACC0044","device_id":"DEV0076","asset_id":"YARD-05","container_id":"CONT-002775"},
]
incident_lookup = {x["incident_id"]: x for x in incidents}

# ---------- 1. Asset inventory ----------
asset_rows = []
for i, asset in enumerate(assets, 1):
    asset_type = "CRANE" if asset.startswith("CRANE") else ("PLC" if asset.startswith("PLC") else "YARD_CONTROLLER")
    zone = "CRANE-ZONE" if asset.startswith("CRANE") else ("OT-ZONE" if asset.startswith("PLC") else "YARD-C")
    criticality = "CRITICAL" if asset.startswith(("CRANE","PLC")) else "HIGH"
    asset_rows.append({
        "asset_id": asset,
        "asset_type": asset_type,
        "zone": zone,
        "criticality": criticality,
        "vendor_supported": "YES" if asset_type in ["CRANE","PLC"] else "NO",
        "owner_group": "OT Engineering" if asset_type in ["CRANE","PLC"] else "Yard Operations",
        "firmware_family": f"FW-{rng.integers(3,8)}.{rng.integers(0,10)}",
        "maintenance_window": "06:00-18:00",
        "internet_exposed": "NO",
    })
asset_df = pd.DataFrame(asset_rows)

# ---------- 2. Vendor VPN/IAM ----------
vpn = []
for i in range(1800):
    account = random.choice(accounts)
    vendor = vendor_account[account]
    device = account_device[account]
    role = account_role[account]
    ts = rand_ts()
    hour = ts.hour
    off_hours = hour < 6 or hour >= 20
    suspicious = rng.random() < (0.045 + (0.025 if off_hours else 0))
    if suspicious:
        # Some suspicious records are tied to the injected incidents.
        auth = rng.choice(["SUCCESS", "FAILURE"], p=[0.82,0.18])
        mfa = rng.choice(["NO","FAILED","YES"], p=[0.50,0.30,0.20])
        src = ip_for(i, malicious=True)
        duration = int(rng.integers(90, 420))
        event_label = "SUSPICIOUS"
        incident_id = ""
        if rng.random() < 0.20:
            inc = random.choice(incidents)
            ts = inc["start"] + timedelta(minutes=int(rng.integers(-2, 12)))
            vendor, account, device = inc["vendor_id"], inc["account_id"], inc["device_id"]
            role = account_role[account]
            incident_id = inc["incident_id"]
    else:
        auth = "SUCCESS" if rng.random() < 0.97 else "FAILURE"
        mfa = "YES" if rng.random() < 0.94 else "FAILED"
        src = ip_for(i, malicious=False)
        duration = int(rng.integers(5, 180))
        event_label = "NORMAL"
        incident_id = ""
    vpn.append({
        "event_id": f"VPN-{i:05d}", "timestamp": fmt(ts), "vendor_id": vendor,
        "account_id": account, "source_ip": src, "device_id": device,
        "auth_result": auth, "MFA_status": mfa, "session_duration_sec": duration,
        "role": role, "access_zone": random.choice(zones),
        "off_hours": "YES" if (ts.hour < 6 or ts.hour >= 20) else "NO",
        "new_device": "YES" if device.endswith(("62","76","87","99")) and suspicious else "NO",
        "event_label": event_label, "incident_id": incident_id
    })
vpn_df = pd.DataFrame(vpn)

# ---------- 3. OT/SCADA/crane telemetry ----------
ot = []
for i in range(2000):
    ts = rand_ts()
    asset = random.choice(assets)
    operator = f"OP{int(rng.integers(1,41)):03d}"
    suspicious = rng.random() < 0.055
    if suspicious:
        command = random.choice(suspicious_commands)
        alarm = random.choice(["ALM-204","ALM-311","ALM-418","ALM-509"])
        state = random.choice(["ABNORMAL","DEGRADED","SAFE_STOP"])
        severity = random.choice(["HIGH","CRITICAL"])
        label = "SUSPICIOUS"
    else:
        command = random.choice(normal_commands)
        alarm = "NONE" if rng.random() < 0.93 else random.choice(["ALM-101","ALM-107"])
        state = random.choice(["NORMAL","RUNNING","IDLE"])
        severity = "LOW" if alarm=="NONE" else "MEDIUM"
        label = "NORMAL"
    incident_id = ""
    if rng.random() < 0.25 and label == "SUSPICIOUS":
        inc = random.choice(incidents)
        ts = inc["start"] + timedelta(minutes=int(rng.integers(0, 18)), seconds=int(rng.integers(0,60)))
        asset = inc["asset_id"]
        incident_id = inc["incident_id"]
    ot.append({
        "event_id": f"OT-{i:05d}", "timestamp": fmt(ts), "asset_id": asset,
        "command_type": command, "alarm_code": alarm, "process_state": state,
        "operator_id": operator, "severity": severity,
        "command_sequence_valid": "NO" if label=="SUSPICIOUS" else "YES",
        "event_label": label, "incident_id": incident_id
    })
ot_df = pd.DataFrame(ot)

# Force explicit incident OT sequences.
forced_ot = []
for inc in incidents:
    for j, cmd in enumerate(["STATUS_READ","PLC_MODE_CHANGE","UNAUTHORIZED_COMMAND","EMERGENCY_STOP"]):
        ts = inc["start"] + timedelta(minutes=6+j)
        forced_ot.append({
            "event_id": f"OT-INC-{inc['incident_id'][-3:]}-{j+1:02d}", "timestamp": fmt(ts),
            "asset_id": inc["asset_id"], "command_type": cmd,
            "alarm_code": ["NONE","ALM-204","ALM-311","ALM-418"][j],
            "process_state": ["RUNNING","ABNORMAL","DEGRADED","SAFE_STOP"][j],
            "operator_id": "OP014", "severity": ["LOW","HIGH","HIGH","CRITICAL"][j],
            "command_sequence_valid": "NO" if j>0 else "YES",
            "event_label": "INCIDENT", "incident_id": inc["incident_id"]
        })
ot_df = pd.concat([ot_df, pd.DataFrame(forced_ot)], ignore_index=True)

# ---------- 4. Network flows ----------
net = []
for i in range(2200):
    ts = rand_ts()
    src_type = random.choice(["Vendor","IT","OT","Yard"])
    malicious = rng.random() < 0.06
    src = ip_for(i, malicious=malicious)
    dst = random.choice(["192.0.2.40","192.0.2.41","192.0.2.42","192.0.2.80","192.0.2.81"])
    if malicious:
        dst_port = random.choice([22,3389,502,44818,8443])
        bytes_out = int(rng.integers(500000, 12000000))
        direction = "OUTBOUND"
        label = "SUSPICIOUS"
        alert = random.choice(["UNUSUAL_OT_CONNECTION","PORT_ANOMALY","LARGE_OUTBOUND_TRANSFER","REMOTE_ADMIN_ACTIVITY"])
    else:
        dst_port = random.choice([80,443,53,502,8080])
        bytes_out = int(rng.integers(500, 800000))
        direction = random.choice(["INTERNAL","OUTBOUND"])
        label = "NORMAL"
        alert = "NONE"
    protocol = random.choice(protocols)
    device = random.choice(devices)
    incident_id = ""
    if malicious and rng.random() < 0.30:
        inc = random.choice(incidents)
        ts = inc["start"] + timedelta(minutes=int(rng.integers(2, 20)))
        device = inc["device_id"]
        incident_id = inc["incident_id"]
    net.append({
        "event_id": f"NET-{i:05d}", "timestamp": fmt(ts), "src_ip": src,
        "dst_ip": dst, "src_port": int(rng.integers(1024,65535)),
        "dst_port": dst_port, "protocol": protocol, "bytes_out": bytes_out,
        "bytes_in": int(rng.integers(200,500000)), "direction": direction,
        "device_id": device, "process_name": random.choice(processes),
        "alert_type": alert, "event_label": label, "incident_id": incident_id
    })
net_df = pd.DataFrame(net)

# ---------- 5. Endpoint alerts ----------
ep = []
for i in range(1200):
    ts = rand_ts()
    device = random.choice(devices)
    suspicious = rng.random() < 0.075
    if suspicious:
        process = random.choice(["remote_admin_tool","plc_tool","powershell_sim","credential_helper_sim"])
        alert_type = random.choice(["SUSPICIOUS_PROCESS","REMOTE_EXECUTION","NEW_REMOTE_TOOL","UNUSUAL_PARENT_PROCESS"])
        severity = random.choice(["MEDIUM","HIGH","CRITICAL"])
        label = "SUSPICIOUS"
    else:
        process = random.choice(processes)
        alert_type = random.choice(["NONE","SOFTWARE_UPDATE","LOGIN","SERVICE_EVENT"])
        severity = "LOW"
        label = "NORMAL"
    incident_id = ""
    if suspicious and rng.random() < 0.35:
        inc = random.choice(incidents)
        ts = inc["start"] + timedelta(minutes=int(rng.integers(1, 16)))
        device = inc["device_id"]
        incident_id = inc["incident_id"]
    ep.append({
        "event_id": f"EDR-{i:05d}", "timestamp": fmt(ts), "device_id": device,
        "hostname": f"PORT-{device}", "user_id": random.choice(accounts),
        "process_name": process, "parent_process": random.choice(["services.exe","explorer.exe","vendor_agent","yard_client"]),
        "alert_type": alert_type, "severity": severity, "event_label": label,
        "incident_id": incident_id
    })
ep_df = pd.DataFrame(ep)

# ---------- 6. Cargo / manifest ----------
cargo = []
for i in range(1200):
    ts = rand_ts()
    container = f"CONT-{int(rng.integers(1,9000)):06d}"
    action = random.choice(["GATE_IN","GATE_OUT","YARD_MOVE","LOAD","UNLOAD","MANIFEST_REVIEW","MANIFEST_CHANGE"])
    suspicious = action=="MANIFEST_CHANGE" and rng.random()<0.22
    label = "SUSPICIOUS" if suspicious else "NORMAL"
    cargo.append({
        "event_id": f"CARGO-{i:05d}", "timestamp": fmt(ts), "container_id": container,
        "yard_zone": random.choice(["YARD-A","YARD-B","YARD-C"]),
        "gate_event": random.choice(["NONE","GATE_IN","GATE_OUT"]),
        "cargo_status": random.choice(["RECEIVED","IN_YARD","LOADED","CLEARED","HOLD"]),
        "manifest_change": "YES" if action=="MANIFEST_CHANGE" else "NO",
        "action": action, "destination_code": random.choice(["DST-A","DST-B","DST-C","DST-D"]),
        "event_label": label, "incident_id": ""
    })
cargo_df = pd.DataFrame(cargo)

# Force incident cargo events.
forced_cargo = []
for inc in incidents:
    forced_cargo.append({
        "event_id": f"CARGO-INC-{inc['incident_id'][-3:]}",
        "timestamp": fmt(inc["start"]+timedelta(minutes=11)),
        "container_id": inc["container_id"], "yard_zone": "YARD-C",
        "gate_event": "NONE", "cargo_status": "CLEARED", "manifest_change": "YES",
        "action": "MANIFEST_CHANGE", "destination_code": "DST-Z",
        "event_label": "INCIDENT", "incident_id": inc["incident_id"]
    })
cargo_df = pd.concat([cargo_df, pd.DataFrame(forced_cargo)], ignore_index=True)

# ---------- 7. Physical access ----------
phys = []
for i in range(1000):
    ts = rand_ts()
    badge = f"BADGE-{int(rng.integers(1,151)):04d}"
    zone = random.choice(zones)
    suspicious = rng.random() < 0.055
    access = "DENIED" if suspicious and rng.random()<0.25 else "GRANTED"
    label = "SUSPICIOUS" if suspicious else "NORMAL"
    phys.append({
        "event_id": f"PHY-{i:05d}", "timestamp": fmt(ts), "badge_id": badge,
        "person_type": random.choice(["Vendor","Operator","Engineer","Security"]),
        "gate_id": random.choice(["GATE-01","GATE-02","GATE-03","GATE-04"]),
        "zone": zone, "access_result": access,
        "direction": random.choice(["IN","OUT"]),
        "event_label": label, "incident_id": ""
    })
phys_df = pd.DataFrame(phys)

# Force incident physical-access events.
forced_phys = []
for inc in incidents:
    forced_phys.append({
        "event_id": f"PHY-INC-{inc['incident_id'][-3:]}",
        "timestamp": fmt(inc["start"]+timedelta(minutes=9)),
        "badge_id": "BADGE-0014", "person_type": "Vendor",
        "gate_id": "GATE-03", "zone": "OT-ZONE",
        "access_result": "GRANTED", "direction": "IN",
        "event_label": "INCIDENT", "incident_id": inc["incident_id"]
    })
phys_df = pd.concat([phys_df, pd.DataFrame(forced_phys)], ignore_index=True)

# ---------- 8. Maintenance / incident text ----------
normal_notes = [
    "Routine inspection completed; no abnormal controller behaviour observed.",
    "Crane maintenance completed within the approved maintenance window.",
    "Vendor session closed normally after firmware verification.",
    "Yard controller communication was stable after scheduled maintenance.",
    "Operator reported normal crane response during load testing.",
]
susp_notes = [
    "Unexpected vendor remote session observed outside the approved maintenance window.",
    "Repeated controller commands were observed during a vendor session; operations requested review.",
    "Crane alarm occurred shortly after an unusual remote connection to the OT segment.",
    "Manifest destination changed during a period of anomalous vendor activity.",
    "Endpoint alert reported a new remote administration tool on a vendor-associated device.",
]
text_rows = []
for i in range(300):
    ts = rand_ts()
    suspicious = rng.random() < 0.22
    if suspicious:
        text = random.choice(susp_notes)
        category = random.choice(["SECURITY_REVIEW","SUSPICIOUS_ACCESS","OT_ANOMALY","CARGO_ANOMALY"])
        priority = random.choice(["HIGH","CRITICAL"])
        label = "SUSPICIOUS"
    else:
        text = random.choice(normal_notes)
        category = random.choice(["MAINTENANCE","INSPECTION","OPERATIONS"])
        priority = random.choice(["LOW","MEDIUM"])
        label = "NORMAL"
    text_rows.append({
        "note_id": f"NOTE-{i:05d}", "timestamp": fmt(ts),
        "asset_id": random.choice(assets), "vendor_id": random.choice(vendors),
        "free_text": text, "category": category, "priority": priority,
        "event_label": label, "incident_id": ""
    })
text_df = pd.DataFrame(text_rows)

forced_notes = []
for inc in incidents:
    forced_notes.append({
        "note_id": f"NOTE-INC-{inc['incident_id'][-3:]}",
        "timestamp": fmt(inc["start"]+timedelta(minutes=13)),
        "asset_id": inc["asset_id"], "vendor_id": inc["vendor_id"],
        "free_text": "Unusual vendor access, endpoint activity and controller commands occurred in close temporal proximity; incident review initiated.",
        "category": "SECURITY_REVIEW", "priority": "CRITICAL",
        "event_label": "INCIDENT", "incident_id": inc["incident_id"]
    })
text_df = pd.concat([text_df, pd.DataFrame(forced_notes)], ignore_index=True)

# Add cross-source incident IDs to a few normal records to create realistic contextual joins.
# Save all primary sources.
datasets = {
    "t21_asset_inventory.csv": asset_df,
    "t21_vendor_vpn_iam.csv": vpn_df,
    "t21_ot_scada_crane.csv": ot_df,
    "t21_network_flows.csv": net_df,
    "t21_endpoint_alerts.csv": ep_df,
    "t21_cargo_manifest.csv": cargo_df,
    "t21_physical_access.csv": phys_df,
    "t21_maintenance_notes.csv": text_df,
}
for filename, df in datasets.items():
    df.to_csv(DATA / filename, index=False)

# ---------- Derived integrated labelled security-event dataset ----------
frames = []
for source, df in [
    ("VPN_IAM", vpn_df), ("OT_SCADA", ot_df), ("NETWORK", net_df),
    ("ENDPOINT", ep_df), ("CARGO", cargo_df), ("PHYSICAL", phys_df), ("TEXT", text_df)
]:
    d = df.copy()
    d["source"] = source
    d["timestamp"] = pd.to_datetime(d["timestamp"], utc=True)
    d["event_label_binary"] = (d["event_label"].isin(["SUSPICIOUS","INCIDENT"])).astype(int)
    if source == "TEXT":
        d["event_id"] = d["note_id"]
    frames.append(d[["event_id","timestamp","source","event_label","event_label_binary","incident_id"]])

events = pd.concat(frames, ignore_index=True).sort_values("timestamp")
events.to_csv(DATA / "t21_integrated_security_events.csv", index=False)

# ---------- Scenario catalogue ----------
scenario_catalogue = pd.DataFrame([
    ["S00","Normal operations","Routine vendor access, normal OT commands, expected network traffic and maintenance.","Normal","Baseline generation"],
    ["S01","Compromised vendor account","Vendor account used outside normal hours with failed/absent MFA, new device, endpoint remote tool, OT commands and cargo change.","Incident","Cross-source correlation"],
    ["S02","Unauthorized OT command sequence","Unexpected PLC/crane command sequence associated with unusual remote access and network connection.","Incident","OT anomaly + timeline"],
    ["S03","Remote administration and data transfer","Suspicious remote administration activity followed by unusual outbound traffic and physical access to restricted OT zone.","Incident","Network + endpoint + physical correlation"],
    ["S04","Cargo/manifest manipulation","Anomalous access coincides with a manifest destination change and maintenance/security notes.","Incident","Cargo integrity analytics"],
], columns=["scenario_id","scenario_name","description","class","primary_use"])
scenario_catalogue.to_csv(DATA / "t21_scenario_catalogue.csv", index=False)

# ---------- Data dictionary ----------
dictionary_rows = []
schemas = {
"t21_asset_inventory.csv": [
("asset_id","string","Unique fictional asset identifier","Join key","No"),
("asset_type","categorical","CRANE, PLC or YARD_CONTROLLER","Asset classification","No"),
("zone","categorical","Operational/security zone","Physical/OT context","No"),
("criticality","categorical","HIGH or CRITICAL","Risk weighting","No"),
("vendor_supported","categorical","YES/NO","Vendor dependency","No"),
("owner_group","string","Fictional operational owner","Context","No"),
("firmware_family","string","Fictional firmware family","Asset context","No"),
("maintenance_window","string","Approved maintenance period","Baseline control","No"),
("internet_exposed","categorical","NO in synthetic environment","Safety control","No"),
],
"t21_vendor_vpn_iam.csv": [
("event_id","string","Unique VPN event ID","Primary key","No"),("timestamp","datetime UTC","Event time","Timeline","No"),
("vendor_id","string","Fictional vendor ID","Entity join","No"),("account_id","string","Fictional account ID","Identity join","No"),
("source_ip","IPv4 string","Documentation/test IP","Network context","No"),("device_id","string","Fictional device ID","Entity join","No"),
("auth_result","categorical","SUCCESS/FAILURE","Access analytics","No"),("MFA_status","categorical","YES/NO/FAILED","Access analytics","No"),
("session_duration_sec","integer","Session duration","Behaviour feature","No"),("role","categorical","Vendor role","Peer baseline","No"),
("access_zone","categorical","Zone requested/accessed","Context","No"),("off_hours","categorical","YES/NO","Anomaly feature","No"),
("new_device","categorical","YES/NO","Anomaly feature","No"),("event_label","categorical","NORMAL/SUSPICIOUS/INCIDENT","Supervised target","Yes"),
("incident_id","string","Cross-source incident identifier","Correlation","No"),
],
"t21_ot_scada_crane.csv": [
("event_id","string","Unique OT event ID","Primary key","No"),("timestamp","datetime UTC","Event time","Timeline","No"),
("asset_id","string","Fictional OT asset","Entity join","No"),("command_type","categorical","Control command","OT analytics","No"),
("alarm_code","string","Fictional alarm code","OT analytics","No"),("process_state","categorical","NORMAL/RUNNING/IDLE/ABNORMAL/DEGRADED/SAFE_STOP","State","No"),
("operator_id","string","Fictional operator ID","Entity context","No"),("severity","categorical","LOW/MEDIUM/HIGH/CRITICAL","Risk feature","No"),
("command_sequence_valid","categorical","YES/NO","Anomaly feature","No"),("event_label","categorical","NORMAL/SUSPICIOUS/INCIDENT","Supervised target","Yes"),
("incident_id","string","Cross-source incident identifier","Correlation","No"),
],
"t21_network_flows.csv": [
("event_id","string","Unique network event ID","Primary key","No"),("timestamp","datetime UTC","Event time","Timeline","No"),
("src_ip","IPv4 string","Documentation/test IP","Network context","No"),("dst_ip","IPv4 string","Documentation/test IP","Network context","No"),
("src_port","integer","Source port","Network feature","No"),("dst_port","integer","Destination port","Network feature","No"),
("protocol","categorical","TCP/UDP/ICMP","Network feature","No"),("bytes_out","integer","Outbound bytes","Exfiltration feature","No"),
("bytes_in","integer","Inbound bytes","Network feature","No"),("direction","categorical","INTERNAL/OUTBOUND","Network context","No"),
("device_id","string","Fictional device ID","Entity join","No"),("process_name","string","Synthetic process name","Endpoint/network context","No"),
("alert_type","categorical","Synthetic network alert","Detection context","No"),("event_label","categorical","NORMAL/SUSPICIOUS/INCIDENT","Supervised target","Yes"),
("incident_id","string","Cross-source incident identifier","Correlation","No"),
],
"t21_endpoint_alerts.csv": [
("event_id","string","Unique endpoint event ID","Primary key","No"),("timestamp","datetime UTC","Event time","Timeline","No"),
("device_id","string","Fictional endpoint ID","Entity join","No"),("hostname","string","Synthetic hostname","Endpoint context","No"),
("user_id","string","Fictional account/user ID","Identity join","No"),("process_name","string","Synthetic process name","Endpoint feature","No"),
("parent_process","string","Synthetic parent process","Endpoint feature","No"),("alert_type","categorical","Synthetic alert type","Detection context","No"),
("severity","categorical","LOW/MEDIUM/HIGH/CRITICAL","Risk feature","No"),("event_label","categorical","NORMAL/SUSPICIOUS/INCIDENT","Supervised target","Yes"),
("incident_id","string","Cross-source incident identifier","Correlation","No"),
],
"t21_cargo_manifest.csv": [
("event_id","string","Unique cargo event ID","Primary key","No"),("timestamp","datetime UTC","Event time","Timeline","No"),
("container_id","string","Fictional container ID","Cargo join","No"),("yard_zone","categorical","Synthetic yard zone","Physical context","No"),
("gate_event","categorical","GATE_IN/GATE_OUT/NONE","Cargo context","No"),("cargo_status","categorical","RECEIVED/IN_YARD/LOADED/CLEARED/HOLD","Cargo context","No"),
("manifest_change","categorical","YES/NO","Integrity feature","No"),("action","categorical","Cargo operation","Behaviour feature","No"),
("destination_code","categorical","Fictional destination code","Cargo context","No"),("event_label","categorical","NORMAL/SUSPICIOUS/INCIDENT","Supervised target","Yes"),
("incident_id","string","Cross-source incident identifier","Correlation","No"),
],
"t21_physical_access.csv": [
("event_id","string","Unique physical-access event ID","Primary key","No"),("timestamp","datetime UTC","Event time","Timeline","No"),
("badge_id","string","Fictional badge ID","Entity context","No"),("person_type","categorical","Vendor/Operator/Engineer/Security","Access context","No"),
("gate_id","categorical","Synthetic gate","Physical context","No"),("zone","categorical","Security/operational zone","Access analytics","No"),
("access_result","categorical","GRANTED/DENIED","Access outcome","No"),("direction","categorical","IN/OUT","Access context","No"),
("event_label","categorical","NORMAL/SUSPICIOUS/INCIDENT","Supervised target","Yes"),("incident_id","string","Cross-source incident identifier","Correlation","No"),
],
"t21_maintenance_notes.csv": [
("note_id","string","Unique text record ID","Primary key","No"),("timestamp","datetime UTC","Note time","Timeline","No"),
("asset_id","string","Fictional asset","Entity join","No"),("vendor_id","string","Fictional vendor","Entity join","No"),
("free_text","text","Synthetic maintenance/incident narrative","NLP input","No"),("category","categorical","Synthetic note category","NLP target/context","No"),
("priority","categorical","LOW/MEDIUM/HIGH/CRITICAL","NLP/risk feature","No"),("event_label","categorical","NORMAL/SUSPICIOUS/INCIDENT","Validation target","Yes"),
("incident_id","string","Cross-source incident identifier","Correlation","No"),
],
}
for ds, cols in schemas.items():
    for col, typ, desc, use, sensitive in cols:
        dictionary_rows.append([ds,col,typ,desc,use,sensitive])
data_dictionary = pd.DataFrame(dictionary_rows, columns=["dataset","field","data_type","description","analytical_use","sensitive_real_data"])
data_dictionary.to_csv(DOCS / "t21_data_dictionary.csv", index=False)

# ---------- Provenance record ----------
provenance = pd.DataFrame([
["t21_vendor_vpn_iam.csv","Synthetic","Python generator; deterministic seed 210821","2026-06-01 to 2026-06-30","Fictional identities, documentation IPs and devices","Synthetic only; no real credentials","Member A / Data and Modelling"],
["t21_ot_scada_crane.csv","Synthetic informed by public ICS schema concepts","Python generator; deterministic seed 210821","2026-06-01 to 2026-06-30","Fictional OT assets, commands and alarms","No live OT data; labels are simulated","Member A / Data and Modelling"],
["t21_network_flows.csv","Synthetic","Python generator; deterministic seed 210821","2026-06-01 to 2026-06-30","Documentation IP ranges and fictional devices","No real network addresses or malware","Member A / Data and Modelling"],
["t21_endpoint_alerts.csv","Synthetic","Python generator; deterministic seed 210821","2026-06-01 to 2026-06-30","Fictional devices, users and process names","No malware samples or personal data","Member B / Security Engineering"],
["t21_cargo_manifest.csv","Synthetic","Python generator; deterministic seed 210821","2026-06-01 to 2026-06-30","Fictional containers and destinations","No real cargo/customer records","Member B / Security Engineering"],
["t21_physical_access.csv","Synthetic","Python generator; deterministic seed 210821","2026-06-01 to 2026-06-30","Fictional badges, gates and zones","No real access-control data","Member B / Security Engineering"],
["t21_maintenance_notes.csv","Synthetic","Python generator; deterministic seed 210821","2026-06-01 to 2026-06-30","Fictional asset/vendor references","No personal data; text is original synthetic text","Member B / Security Engineering"],
["t21_asset_inventory.csv","Synthetic","Python generator; deterministic seed 210821","Static project context","Fictional assets and ownership groups","No real infrastructure details","Joint"],
["t21_integrated_security_events.csv","Derived from the seven event sources","Generated by deterministic join/normalisation step","2026-06-01 to 2026-06-30","Inherited from synthetic sources","No real data","Joint"],
], columns=["dataset","provenance_type","generation_or_source_method","date_range","identifier_policy","security_ethics_control","primary_owner"])
provenance.to_csv(DOCS / "t21_provenance_record.csv", index=False)

# ---------- Methodology document ----------
methodology = f"""# T21 Maritime Port Security Analytics — Data Generation Methodology

## 1. Purpose
This package provides a controlled, fictional multi-source dataset for the SAS821S T21 project:
**Maritime Port and Cargo-Terminal Cyber-Physical Security Analytics**.

The dataset is designed to support data engineering, behavioural baselining, supervised and unsupervised analytics,
incident timeline reconstruction, security intelligence, simulation, NLP, predictive risk scoring and adversarial testing.

## 2. Alignment with the approved project
The project charter specifies synthetic representations of OT/SCADA telemetry, vendor VPN/IAM access, network flows,
cargo/manifest events, physical access, endpoint alerts and maintenance notes. The capstone specification requires
at least three security sources, at least 5,000 combined records, a labelled dataset, an unlabelled/semi-labelled
dataset, at least 200 text records and documented provenance.

## 3. Synthetic environment
The fictional environment represents a container terminal with:
- 8 cranes
- 12 PLC assets
- 8 yard controllers
- 20 fictional vendors
- 60 fictional accounts
- 100 fictional devices
- 150 fictional badges
- fictional containers, gates and operational zones

No real port, company, customer, employee, vendor credential or production system is represented.

## 4. Primary datasets and volumes
| Dataset | Target/actual records | Main analytical purpose |
|---|---:|---|
| t21_vendor_vpn_iam.csv | {len(vpn_df):,} | Identity/access and vendor behaviour |
| t21_ot_scada_crane.csv | {len(ot_df):,} | OT/SCADA command and alarm analytics |
| t21_network_flows.csv | {len(net_df):,} | Network anomaly and intrusion analytics |
| t21_endpoint_alerts.csv | {len(ep_df):,} | Endpoint security analytics |
| t21_cargo_manifest.csv | {len(cargo_df):,} | Cargo-integrity context |
| t21_physical_access.csv | {len(phys_df):,} | Physical access correlation |
| t21_maintenance_notes.csv | {len(text_df):,} | Text mining/NLP |
| t21_asset_inventory.csv | {len(asset_df):,} | Asset and operational context |
| t21_integrated_security_events.csv | {len(events):,} | Derived cross-source event index |

The seven event sources alone contain {sum(len(x) for x in [vpn_df,ot_df,net_df,ep_df,cargo_df,phys_df,text_df]):,} event/transaction records.

## 5. Time and identifiers
All timestamps are stored in UTC ISO-8601 format.
Common correlation identifiers include:
- vendor_id
- account_id
- device_id
- asset_id
- incident_id
- timestamp

Incident windows use shared incident_id values so events from multiple sources can be reconstructed chronologically.

## 6. Scenario injection
Four controlled incident scenarios are injected into otherwise normal synthetic activity:

- S01 — Compromised vendor account
- S02 — Unauthorized OT command sequence
- S03 — Remote administration and unusual data transfer
- S04 — Cargo/manifest manipulation

A separate S00 normal-operation scenario forms the behavioural baseline.

The injected events are intentionally non-operational and do not provide instructions for attacking real systems.

## 7. Label strategy
The primary event labels are:
- NORMAL
- SUSPICIOUS
- INCIDENT

For modelling, NORMAL is mapped to binary 0 and SUSPICIOUS/INCIDENT to binary 1.
Labels are generated from the scenario logic rather than copied from real incidents.

## 8. Data quality controls
The generator uses:
- fixed random seed: {SEED}
- explicit field types and controlled categorical values
- fictional/test identifiers
- consistent UTC timestamps
- deterministic cross-source incident IDs
- documented generation rules
- no real credentials or customer data

## 9. Intended analytical use
The package supports:
1. descriptive statistics and baseline analysis;
2. supervised classification;
3. anomaly/behavioural detection;
4. cross-source incident investigation;
5. threat-intelligence enrichment;
6. three-control simulation;
7. NLP on maintenance/incident text;
8. predictive risk scoring and robustness/adversarial tests.

## 10. Limitations
This is a synthetic research dataset. It does not represent the actual traffic, control logic, asset configuration,
risk profile or operational procedures of a real port. Results must therefore be interpreted as prototype/educational
evidence rather than production security measurements.

## 11. Reproducibility
Run:

```bash
python code/generate_t21_dataset.py
```

The generator recreates the CSV outputs using the same seed. The package should be version-controlled so that
changes to generation logic and outputs can be audited.
"""
(DOCS / "data_generation_methodology.md").write_text(methodology, encoding="utf-8")

# ---------- Scenario injection details ----------
scenario_details = """# T21 Scenario Injection Specification

| Scenario | Core signal chain | Expected analytical evidence |
|---|---|---|
| S00 Normal | Routine VPN -> normal endpoint -> normal OT/network activity | Baseline |
| S01 Compromised vendor account | Off-hours VPN + weak/failed MFA + new device -> endpoint remote tool -> OT command -> cargo change | Account compromise hypothesis |
| S02 Unauthorized OT sequence | Vendor access -> OT mode change -> unauthorized command -> crane/PLC alarm | OT command anomaly |
| S03 Remote admin/data transfer | Remote administration -> unusual outbound traffic -> restricted physical access | Endpoint/network/physical correlation |
| S04 Cargo manipulation | Anomalous access -> manifest destination change -> security/maintenance note | Cargo-integrity anomaly |

All scenario events are fictional and use non-operational identifiers.
"""
(DOCS / "scenario_injection_specification.md").write_text(scenario_details, encoding="utf-8")

# ---------- README ----------
readme = f"""# T21 Maritime Port Security Analytics — Synthetic Dataset Package

Generated: 2026-09-15
Random seed: {SEED}
Date range: 2026-06-01 to 2026-06-30 UTC

## Contents
- `data/` — eight primary synthetic datasets plus integrated event index and scenario catalogue.
- `documentation/` — data dictionary, provenance record, generation methodology and scenario specification.
- `code/generate_t21_dataset.py` — reproducible generator.

## Safety and academic-use statement
All identities, IP addresses, devices, assets, containers, badges, alarms and events are fictional.
Documentation/test IP ranges are used. No live port, OT, SCADA, crane, vendor or customer data is included.

## Main record count
Seven event sources: {sum(len(x) for x in [vpn_df,ot_df,net_df,ep_df,cargo_df,phys_df,text_df]):,}
Asset inventory: {len(asset_df):,}
"""
(DOCS / "README.md").write_text(readme, encoding="utf-8")

