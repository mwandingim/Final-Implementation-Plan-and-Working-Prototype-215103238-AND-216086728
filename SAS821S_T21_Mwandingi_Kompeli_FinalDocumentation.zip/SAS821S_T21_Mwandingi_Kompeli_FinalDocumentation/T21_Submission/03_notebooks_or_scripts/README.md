# Python Implementation

Core reproducible analysis scripts:

1. `00_generate_t21_dataset.py` — generate the controlled synthetic dataset.
2. `01_validate_dataset.py` — validate data quality and governance checks.
3. `03_baseline_eda.py` — baseline and exploratory analysis.
4. `05_supervised_model.py` — supervised security model.
5. `07_anomaly_access_analytics.py` — Isolation Forest anomaly analytics.
6. `08_incident_investigation.py` — cross-source incident correlation.
7. `10_security_intelligence.py` — PIRs, enrichment and intelligence products.
8. `12_simulation.py` — control scenario simulation.
9. `14_text_mining_nlp.py` — TF-IDF/NLP text classification.
10. `16_predictive_adversarial.py` — predictive risk and adversarial testing.
11. `18_prototype.py` — analyst-facing prototype generation.
12. `19_final_qa.py` — final QA checks.
13. `run_analysis_pipeline.py` — executes the core workflow in sequence.

Scripts beginning with `02`, `04`, `06`, `09`, `11`, `13`, `15`, `17`, `20` and `21` are historical documentation-update utilities retained for auditability; they are not required to reproduce the analytical results.
