# Simulation
Simulation implementation is in `03_notebooks_or_scripts/12_simulation.py`.
Results are stored in `08_outputs/simulation/`.
