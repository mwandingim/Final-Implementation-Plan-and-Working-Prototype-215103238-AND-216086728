# Text Mining
NLP implementation is in `03_notebooks_or_scripts/14_text_mining_nlp.py`.
Results and figures are stored in `08_outputs/text_mining/`.
